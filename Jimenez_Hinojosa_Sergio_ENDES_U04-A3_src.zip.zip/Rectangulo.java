package figuras;
import java.awt.Color;
/**
 * Clase que representa un rectángulo.
 * Permite calcular área y perímetro.
 * 
 * @author Sergio
 * @version 1.0
 */
public class Rectangulo extends Figura{

private double base;
private double altura;
/**
 * Constructor del rectángulo.
 * 
 * @param x Coordenada X del centro
 * @param y Coordenada Y del centro
 * @param color Color del rectángulo
 * @param base Base
 * @param altura Altura
 */
public Rectangulo (double x, double y, Color color, double base, double altura){
super (x, y, color);this.base = base;this.altura = altura;
}
/** @return base */
public double getBase(){return base;}
/** @return altura */
public double getAltura(){return altura;}
/** @param base nueva base */
public void setBase(double base){this.base = base;}
/** @param altura nueva altura */
public void setAltura(double altura){this.altura = altura;}
/**
 * Calcula el perímetro.
 * 
 * @return perímetro
 */
public double perimetro (){return 2 * base + 2 * altura;}
/**
 * Calcula el área.
 * 
 * @return área
 */
public double area (){return base * altura;}
}