package figuras;
import java.awt.Color;
/**
 * Clase abstracta que representa una figura geométrica.
 * Define métodos comunes para todas las figuras.
 * 
 * @author Sergio
 * @version 1.0
 */
public abstract class Figura{
private Punto centro;
private Color color;
/**
 * Constructor de la figura.
 * 
 * @param x Coordenada X del centro
 * @param y Coordenada Y del centro
 * @param color Color de la figura
 */
public Figura(double x, double y, Color color){
centro = new Punto (x, y);
this.color = color;
}
/** @return coordenada X */
public double getXCentro(){return centro.getX();}
/** @return coordenada Y */
public double getYCentro(){return centro.getY();}
/** @return color */
public Color getColor(){return color;}
/** @param x nueva coordenada X */
public void setXCentro(double x){centro.setX (x);}
/** @param y nueva coordenada Y */
public void setYCentro(double y){centro.setY (y);}
/** @param color nuevo color */
public void setColor(Color color){this.color = color;}
/**
 * Calcula el perímetro.
 * 
 * @return perímetro
 */
public abstract double perimetro();
/**
 * Calcula el área.
 * 
 * @return área
 */
public abstract double area();
/**
 * Compara dos figuras por su área.
 * 
 * @param otraFigura figura a comparar
 * @return 1 si es mayor, -1 si es menor, 0 si son iguales
 */
public int esMayorQue (Figura otraFigura) {
int codigo;
if (this.area() > otraFigura.area()) codigo = 1;
else
if (this.area() < otraFigura.area()) codigo = -1;
else codigo = 0;
return codigo;
}
}