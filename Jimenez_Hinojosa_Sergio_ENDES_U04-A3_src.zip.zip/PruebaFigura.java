package figuras;
import java.util.Scanner;
import java.awt.Color;
public class PruebaFigura {
	public double calcularArea() {
	    return Math.PI * radio * radio;
	}
private static final String DEBE_INTRODUCIR_UN_NUMERO_ENTRE_1_Y_4 = "Debe introducir un numero entre 1 y 4";
private static final String INTRODUZCA_UNA_OPCION_1_4 = "Introduzca una opcion (1-4): ";
private static final String INTRODUZCA_EL_LADO_DEL_CUADRADO = "Introduzca el lado del cuadrado: ";
private static final String EL_ÁREA_ES = "El área es ";
private static final String EL_PERÍMETRO_ES = "El perímetro es ";
private static final String INTRODUZCA_EL_LADO_3_DEL_TRIÁNGULO = "Introduzca el lado 3 del triángulo: ";
private static final String INTRODUZCA_EL_LADO_2_DEL_TRIÁNGULO = "Introduzca el lado 2 del triángulo: ";
private static final String INTRODUZCA_LA_COORDENADA_Y_DEL_CENTRO = "Introduzca la coordenada y del centro: ";
private static final String INTRODUZCA_LA_COORDENADA_X_DEL_CENTRO = "Introduzca la coordenada x del centro: ";
private static final String INTRODUZCA_EL_LADO_1_DEL_TRIÁNGULO = "Introduzca el lado 1 del triángulo: ";
private static int opcion;
public static void main(String[] args) {
Scanner teclado = new Scanner (System.in);
do { 
opcion = mostrarMenu();
if (opcion != 4){
System.out.print (INTRODUZCA_LA_COORDENADA_X_DEL_CENTRO);
double x = teclado.nextDouble();
System.out.print (INTRODUZCA_LA_COORDENADA_Y_DEL_CENTRO);
double y = teclado.nextDouble();
switch (opcion)  {
case 1:
	extracted(teclado, x, y);
break;
case 2:
	extracted(teclado, x, y);
break;
case 3:
	extracted(teclado, x, y);
break;
}
}
}while (opcion != 4); 
teclado.close();
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	System.out.print (INTRODUZCA_EL_LADO_DEL_CUADRADO);
	double lado = teclado.nextDouble();
	Cuadrado c = new Cuadrado(x, y, Color.red, lado);
	System.out.println (EL_PERÍMETRO_ES + c.perimetro());
	System.out.println (EL_ÁREA_ES + c.area());
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	System.out.print ("Introduzca la base del rectángulo: ");
	double base = teclado.nextDouble();
	System.out.print ("Introduzca la altura del rectángulo: ");
	double altura = teclado.nextDouble();
	Rectangulo r = new Rectangulo(x, y, Color.red, base, altura);
	System.out.println (EL_PERÍMETRO_ES + r.perimetro());
	System.out.println (EL_ÁREA_ES + r.area());
}
private static void extracted(Scanner teclado, double x, double y) {
	extracted(teclado, x, y);
}
private static void extracted(Scanner teclado, double x, double y) {
	System.out.print (INTRODUZCA_EL_LADO_1_DEL_TRIÁNGULO);
	double lado1 = teclado.nextDouble();
	System.out.print (INTRODUZCA_EL_LADO_2_DEL_TRIÁNGULO);
	double lado2 = teclado.nextDouble();
	System.out.print (INTRODUZCA_EL_LADO_3_DEL_TRIÁNGULO);
	double lado3 = teclado.nextDouble();
	Triangulo t = new Triangulo(x, y, Color.red, lado1, lado2, lado3);
	System.out.println (EL_PERÍMETRO_ES + t.perimetro());
	System.out.println (EL_ÁREA_ES + t.area());
}
public static int mostrarMenu(){
int opcion;
Scanner teclado = extracted();
do {
System.out.print (INTRODUZCA_UNA_OPCION_1_4);
opcion = teclado.nextInt();
if (opcion < 1 || opcion > 4)
System.out.println (DEBE_INTRODUCIR_UN_NUMERO_ENTRE_1_Y_4);
} while (opcion < 1 || opcion > 4);
return opcion;
}
private static Scanner extracted() {
	int opcion;
	System.out.println ("1) Triangulo");
	System.out.println ("2) Rectangulo");
	System.out.println ("3) Cuadrado");
	System.out.println ("4) Salir");
	Scanner teclado = new Scanner (System.in);
	return teclado;
}
}