package figuras;
/**
 * Clase que representa un punto en el plano cartesiano.
 * Permite realizar operaciones básicas con puntos.
 * 
 * @author Sergio
 * @version 1.0
 */
public class Punto {
private double x;
private double y;
/** Constructor por defecto */
public Punto(){x = 0;y= 0;}
/**
 * Constructor con parámetros.
 * 
 * @param x Coordenada X
 * @param y Coordenada Y
 */
public Punto(double x, double y){this.x = x;this.y = y;}
/**
 * Constructor copia.
 * 
 * @param p Punto a copiar
 */
public Punto(Punto p){x = p.x;y = p.y;}
/** @return coordenada X */
public double getX(){return x;}
/** @return coordenada Y */
public double getY(){return y;}
/** @param x nueva coordenada X */
public void setX(double x){this.x = x;}
/** @param y nueva coordenada Y */
public void setY(double y){this.y = y;}
/**
 * Calcula la distancia a otro punto.
 * 
 * @param p Punto destino
 * @return distancia
 */
public double distancia(Punto p){return Math.sqrt (Math.pow(p.x - this.x, 2) + Math.pow(p.y - this.y, 2));}
/**
 * Devuelve el punto simétrico respecto al eje Y.
 * 
 * @return nuevo punto simétrico
 */
public Punto simétrico(){
Punto nuevoP = new Punto (this.x * -1, this.y);	
return nuevoP ;
}
/**
 * Compara dos puntos.
 * 
 * @param p Punto a comparar
 * @return true si son iguales
 */
public boolean compara(Punto p){
if (p.x == x && p.y == y)
return true;
else
return false;
}
/**
 * Representación en texto.
 * 
 * @return string del punto
 */
public String toString() {return "(" + getX() + "," + getY() + ")";}
}