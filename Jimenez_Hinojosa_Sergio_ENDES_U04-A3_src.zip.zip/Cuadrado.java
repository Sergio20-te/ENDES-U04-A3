package figuras;
import java.awt.Color;
/**
 * Clase que representa un cuadrado.
 * Hereda de la clase Rectangulo, donde base y altura son iguales.
 * 
 * @author Sergio
 * @version 1.0
 */
public class Cuadrado extends Rectangulo{
	  /**
     * Constructor de la clase Cuadrado.
     * 
     * @param x Coordenada X del centro
     * @param y Coordenada Y del centro
     * @param color Color del cuadrado
     * @param lado Longitud del lado
     */
public Cuadrado (double x, double y, Color color, double lado){
super (x, y, color, lado, lado);
}
}